import { createFileRoute } from "@tanstack/react-router";

// The SONORA site is a standalone HTML/Bootstrap/JS project in public/sonora.
// This route only displays it full-screen in the preview.
export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "SONORA · Tu música, tu mundo" },
      {
        name: "description",
        content:
          "SONORA: escucha música, busca artistas y álbumes, guarda favoritas y crea tus playlists.",
      },
      { property: "og:title", content: "SONORA · Tu música, tu mundo" },
      {
        property: "og:description",
        content: "Plataforma de música con reproductor, favoritas y playlists.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

function Index() {
  return (
    <iframe
      src="/sonora/index.html?v=expanded-15-tracks-20261125"
      title="SONORA"
      className="fixed inset-0 h-full w-full border-0 bg-background"
      allow="autoplay"
    />
  );
}
