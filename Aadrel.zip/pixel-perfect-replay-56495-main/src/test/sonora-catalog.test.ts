import { readFileSync } from "node:fs";
import { runInNewContext } from "node:vm";
import { describe, expect, it } from "vitest";

const script = readFileSync("public/sonora/js/script.js", "utf8");
const data = script.split("/* ---------- 2. ESTADO")[0];
if (!data) throw new Error("Missing SONORA catalog");
const catalog = runInNewContext(`${data}; ({ songs, albums, artists })`) as {
  songs: { id: number; title: string; artist: string; album: string; genre: string; src: string; cover: string }[];
  albums: { title: string; songs: number[] }[];
  artists: { name: string }[];
};

describe("SONORA real music catalog", () => {
  it("replaces fictional artists with real recordings rather than unrelated demo audio", () => {
    expect(catalog.songs.slice(0, 5).map((song) => [song.title, song.artist])).toEqual([
      ["Take a Walk", "Passion Pit"],
      ["Mystical Magical", "Benson Boone"],
      ["La Da Dee", "Cody Simpson"],
      ["There's Nothing Holdin' Me Back", "Shawn Mendes"],
      ["Immortals", "Fall Out Boy"],
    ]);
    for (const song of catalog.songs) {
      expect(catalog.artists.some((artist) => song.artist.includes(artist.name))).toBe(true);
      expect(new URL(song.src).hostname).toBe("audio-ssl.itunes.apple.com");
      expect(song.src).toContain("AudioPreview");
      expect(song.cover).toContain("/__l5e/assets-v1/");
    }
    for (const album of catalog.albums) {
      for (const id of album.songs) {
        expect(catalog.songs.find((song) => song.id === id)?.album).toBe(album.title);
      }
    }
  });

  it("adds exactly ten more songs without replacing the five selected songs", () => {
    expect(catalog.songs).toHaveLength(15);
    expect(new Set(catalog.songs.map((song) => song.id)).size).toBe(15);
    expect(catalog.songs.slice(5).map((song) => song.title)).toEqual([
      "Carried Away",
      "Beautiful Things",
      "On My Mind",
      "Stitches",
      "My Songs Know What You Did In The Dark (Light Em Up)",
      "Counting Stars",
      "Animal",
      "Shut Up and Dance",
      "Good Time",
      "Best Day of My Life",
    ]);
  });

  it("keeps all ten additions within the original pop, indie pop and rock genres", () => {
    for (const song of catalog.songs.slice(5)) {
      expect(["Pop", "Indie pop", "Rock"]).toContain(song.genre);
    }
  });
});