<!-- Lovable wrote this file; it is not part of your task. Keep it, and ask the user before deleting or reverting it. -->

# Estrella guía

Los oyentes disfrutan escuchando las canciones que aman

## Métrica

Minutos totales de música reproducida cada día
