/* ==========================================================
   SONORA · Lógica de la aplicación (JavaScript puro)
   ----------------------------------------------------------
   1. Datos de ejemplo
   2. Estado y almacenamiento local
   3. Utilidades (alertas, formato de tiempo)
   4. Plantillas HTML (tarjetas y filas)
   5. Renderizado de cada sección
   6. Navegación entre secciones
   7. Reproductor de audio
   8. Favoritos y playlists
   9. Búsqueda
   10. Inicio de sesión / perfil
   11. Eventos
   ========================================================== */

/* ---------- 1. DATOS DE EJEMPLO ---------- */
// Canciones reales con fragmentos oficiales del catálogo de Apple/iTunes.
// Son vistas previas, no canciones completas; requieren conexión a internet.
const songs = [
  {
    "id": 1,
    "title": "Take a Walk",
    "artist": "Passion Pit",
    "album": "Gossamer",
    "genre": "Indie pop",
    "plays": 98,
    "cover": "/__l5e/assets-v1/c2347504-ea2f-4c8a-b4f8-0d5faf919083/sonora-selected-1.jpg",
    "src": "https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview211/v4/d0/42/b7/d042b7cd-b962-f05f-db52-fb76a144b2dc/mzaf_5287739157916939848.plus.aac.p.m4a"
  },
  {
    "id": 2,
    "title": "Mystical Magical",
    "artist": "Benson Boone",
    "album": "American Heart",
    "genre": "Pop",
    "plays": 91,
    "cover": "/__l5e/assets-v1/02d8ca47-ca54-414d-89b2-e61a56d5343e/sonora-selected-2.jpg",
    "src": "https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview211/v4/15/c1/68/15c1688d-344a-e864-923f-4a98c7f62844/mzaf_13844142046274324768.plus.aac.p.m4a"
  },
  {
    "id": 3,
    "title": "La Da Dee",
    "artist": "Cody Simpson",
    "album": "Surfers Paradise",
    "genre": "Pop",
    "plays": 85,
    "cover": "/__l5e/assets-v1/497e5d77-c4c9-4234-83da-401e77a07340/sonora-selected-3.jpg",
    "src": "https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview221/v4/37/bd/29/37bd29b8-9708-c298-d449-a1a7328e4719/mzaf_325263787095862512.plus.aac.p.m4a"
  },
  {
    "id": 4,
    "title": "There's Nothing Holdin' Me Back",
    "artist": "Shawn Mendes",
    "album": "Illuminate (Deluxe)",
    "genre": "Pop",
    "plays": 95,
    "cover": "/__l5e/assets-v1/34c722a5-bd02-47ac-8359-2f933f9ec70f/sonora-selected-4.jpg",
    "src": "https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview211/v4/87/1c/bc/871cbc00-24a6-c95a-b9bb-49ff209c6777/mzaf_13131899989124950522.plus.aac.p.m4a"
  },
  {
    "id": 5,
    "title": "Immortals",
    "artist": "Fall Out Boy",
    "album": "Big Hero 6 (Original Motion Picture Soundtrack)",
    "genre": "Rock",
    "plays": 90,
    "cover": "/__l5e/assets-v1/c39d4550-8048-4a00-b77f-48ce6d3478e1/sonora-selected-5.jpg",
    "src": "https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview221/v4/cc/d4/f2/ccd4f2e7-043a-afc1-705b-6f662575bf23/mzaf_3158763562070326261.plus.aac.p.m4a"
  },
  {
    "id": 6,
    "title": "Carried Away",
    "artist": "Passion Pit",
    "album": "Gossamer",
    "genre": "Indie pop",
    "plays": 84,
    "cover": "/__l5e/assets-v1/001aab50-b115-44e9-851d-cc3e4eaac292/sonora-extra-6.jpg",
    "src": "https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview221/v4/1b/39/c7/1b39c7f2-0a02-800e-d7fe-054b9bb180be/mzaf_16442410928085168633.plus.aac.p.m4a"
  },
  {
    "id": 7,
    "title": "Beautiful Things",
    "artist": "Benson Boone",
    "album": "Beautiful Things - Single",
    "genre": "Pop",
    "plays": 83,
    "cover": "/__l5e/assets-v1/11c6b3f4-6cca-430e-81a4-85c3dee802cb/sonora-extra-7.jpg",
    "src": "https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview211/v4/4d/d5/00/4dd5006f-ee02-c3f1-94db-0ed4b8dd68f1/mzaf_14250561294796027079.plus.aac.p.m4a"
  },
  {
    "id": 8,
    "title": "On My Mind",
    "artist": "Cody Simpson",
    "album": "On My Mind - Single",
    "genre": "Pop",
    "plays": 82,
    "cover": "/__l5e/assets-v1/d4d0de6e-a087-48e5-8adf-27f8d6427394/sonora-extra-8.jpg",
    "src": "https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview122/v4/66/00/a6/6600a6e0-8e8a-9259-bac3-931c0edc369c/mzaf_5635903398332488045.plus.aac.p.m4a"
  },
  {
    "id": 9,
    "title": "Stitches",
    "artist": "Shawn Mendes",
    "album": "Handwritten (Revisited)",
    "genre": "Pop",
    "plays": 81,
    "cover": "/__l5e/assets-v1/006acaf2-6b26-4da7-8f6d-b14883e6438b/sonora-extra-9.jpg",
    "src": "https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview211/v4/e8/7c/7d/e87c7ddf-d844-6485-085b-95f15f9ee423/mzaf_12884712290949429165.plus.aac.p.m4a"
  },
  {
    "id": 10,
    "title": "My Songs Know What You Did In The Dark (Light Em Up)",
    "artist": "Fall Out Boy",
    "album": "Save Rock And Roll",
    "genre": "Rock",
    "plays": 80,
    "cover": "/__l5e/assets-v1/6e715b79-33ca-4096-8e10-a863e31db194/sonora-extra-10.jpg",
    "src": "https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview221/v4/a9/24/b5/a924b5b7-62cb-58de-8a67-840e350ee36b/mzaf_16782497682409176243.plus.aac.p.m4a"
  },
  {
    "id": 11,
    "title": "Counting Stars",
    "artist": "OneRepublic",
    "album": "Native",
    "genre": "Pop",
    "plays": 79,
    "cover": "/__l5e/assets-v1/3bf9ef2f-2d40-486e-b520-c73ef561dd25/sonora-extra-11.jpg",
    "src": "https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview221/v4/8a/e6/26/8ae626cc-ede8-47d2-d86b-ce7fd562e4d1/mzaf_15251194521255976653.plus.aac.p.m4a"
  },
  {
    "id": 12,
    "title": "Animal",
    "artist": "Neon Trees",
    "album": "Habits (Exclusive Edition)",
    "genre": "Indie pop",
    "plays": 78,
    "cover": "/__l5e/assets-v1/0f8dbbbe-f276-454d-822c-2d52fa96a8f6/sonora-extra-12.jpg",
    "src": "https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview211/v4/52/79/38/527938e9-29c2-3d36-26b8-2a7866b99f2f/mzaf_11162636893383832665.plus.aac.p.m4a"
  },
  {
    "id": 13,
    "title": "Shut Up and Dance",
    "artist": "WALK THE MOON",
    "album": "TALKING IS HARD (Expanded Edition)",
    "genre": "Indie pop",
    "plays": 77,
    "cover": "/__l5e/assets-v1/dcd2df99-35b3-4589-9eca-5b6ed3812841/sonora-extra-13.jpg",
    "src": "https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview211/v4/fa/37/b0/fa37b02c-cccc-7ccb-3161-39a5f4c2d4e8/mzaf_1832266719592545746.plus.aac.p.m4a"
  },
  {
    "id": 14,
    "title": "Good Time",
    "artist": "Owl City & Carly Rae Jepsen",
    "album": "The Midsummer Station",
    "genre": "Pop",
    "plays": 76,
    "cover": "/__l5e/assets-v1/73a0b8fd-770b-43e8-8ec2-0aa8a493d81b/sonora-extra-14.jpg",
    "src": "https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview211/v4/0f/82/0c/0f820caf-5ad1-3b5b-c5a7-c703f382494f/mzaf_2570256569082929759.plus.aac.p.m4a"
  },
  {
    "id": 15,
    "title": "Best Day of My Life",
    "artist": "American Authors",
    "album": "Oh, What a Life",
    "genre": "Indie pop",
    "plays": 75,
    "cover": "/__l5e/assets-v1/ebf0621f-f30a-4455-80fa-bda03e66fd6c/sonora-extra-15.jpg",
    "src": "https://audio-ssl.itunes.apple.com/itunes-assets/AudioPreview221/v4/22/30/d0/2230d086-6407-6aa5-e8ff-3e0f81d2bfc1/mzaf_7188612954736160603.plus.aac.p.m4a"
  }
];

const albums = [
  {
    "id": "a1",
    "title": "Gossamer",
    "artist": "Passion Pit",
    "year": 2012,
    "cover": "/__l5e/assets-v1/c2347504-ea2f-4c8a-b4f8-0d5faf919083/sonora-selected-1.jpg",
    "songs": [
      1,
      6
    ]
  },
  {
    "id": "a2",
    "title": "American Heart",
    "artist": "Benson Boone",
    "year": 2025,
    "cover": "/__l5e/assets-v1/02d8ca47-ca54-414d-89b2-e61a56d5343e/sonora-selected-2.jpg",
    "songs": [
      2
    ]
  },
  {
    "id": "a3",
    "title": "Surfers Paradise",
    "artist": "Cody Simpson",
    "year": 2013,
    "cover": "/__l5e/assets-v1/497e5d77-c4c9-4234-83da-401e77a07340/sonora-selected-3.jpg",
    "songs": [
      3
    ]
  },
  {
    "id": "a4",
    "title": "Illuminate (Deluxe)",
    "artist": "Shawn Mendes",
    "year": 2016,
    "cover": "/__l5e/assets-v1/34c722a5-bd02-47ac-8359-2f933f9ec70f/sonora-selected-4.jpg",
    "songs": [
      4
    ]
  },
  {
    "id": "a5",
    "title": "Big Hero 6 (Original Motion Picture Soundtrack)",
    "artist": "Fall Out Boy",
    "year": 2014,
    "cover": "/__l5e/assets-v1/c39d4550-8048-4a00-b77f-48ce6d3478e1/sonora-selected-5.jpg",
    "songs": [
      5
    ]
  },
  {
    "id": "a6",
    "title": "Beautiful Things - Single",
    "artist": "Benson Boone",
    "year": 2024,
    "cover": "/__l5e/assets-v1/11c6b3f4-6cca-430e-81a4-85c3dee802cb/sonora-extra-7.jpg",
    "songs": [
      7
    ]
  },
  {
    "id": "a7",
    "title": "On My Mind - Single",
    "artist": "Cody Simpson",
    "year": 2011,
    "cover": "/__l5e/assets-v1/d4d0de6e-a087-48e5-8adf-27f8d6427394/sonora-extra-8.jpg",
    "songs": [
      8
    ]
  },
  {
    "id": "a8",
    "title": "Handwritten (Revisited)",
    "artist": "Shawn Mendes",
    "year": 2015,
    "cover": "/__l5e/assets-v1/006acaf2-6b26-4da7-8f6d-b14883e6438b/sonora-extra-9.jpg",
    "songs": [
      9
    ]
  },
  {
    "id": "a9",
    "title": "Save Rock And Roll",
    "artist": "Fall Out Boy",
    "year": 2013,
    "cover": "/__l5e/assets-v1/6e715b79-33ca-4096-8e10-a863e31db194/sonora-extra-10.jpg",
    "songs": [
      10
    ]
  },
  {
    "id": "a10",
    "title": "Native",
    "artist": "OneRepublic",
    "year": 2013,
    "cover": "/__l5e/assets-v1/3bf9ef2f-2d40-486e-b520-c73ef561dd25/sonora-extra-11.jpg",
    "songs": [
      11
    ]
  },
  {
    "id": "a11",
    "title": "Habits (Exclusive Edition)",
    "artist": "Neon Trees",
    "year": 2010,
    "cover": "/__l5e/assets-v1/0f8dbbbe-f276-454d-822c-2d52fa96a8f6/sonora-extra-12.jpg",
    "songs": [
      12
    ]
  },
  {
    "id": "a12",
    "title": "TALKING IS HARD (Expanded Edition)",
    "artist": "WALK THE MOON",
    "year": 2014,
    "cover": "/__l5e/assets-v1/dcd2df99-35b3-4589-9eca-5b6ed3812841/sonora-extra-13.jpg",
    "songs": [
      13
    ]
  },
  {
    "id": "a13",
    "title": "The Midsummer Station",
    "artist": "Owl City & Carly Rae Jepsen",
    "year": 2012,
    "cover": "/__l5e/assets-v1/73a0b8fd-770b-43e8-8ec2-0aa8a493d81b/sonora-extra-14.jpg",
    "songs": [
      14
    ]
  },
  {
    "id": "a14",
    "title": "Oh, What a Life",
    "artist": "American Authors",
    "year": 2013,
    "cover": "/__l5e/assets-v1/ebf0621f-f30a-4455-80fa-bda03e66fd6c/sonora-extra-15.jpg",
    "songs": [
      15
    ]
  }
];

const artists = [
  {
    "name": "Passion Pit",
    "genre": "Indie pop",
    "image": "/__l5e/assets-v1/c2347504-ea2f-4c8a-b4f8-0d5faf919083/sonora-selected-1.jpg"
  },
  {
    "name": "Benson Boone",
    "genre": "Pop",
    "image": "/__l5e/assets-v1/02d8ca47-ca54-414d-89b2-e61a56d5343e/sonora-selected-2.jpg"
  },
  {
    "name": "Cody Simpson",
    "genre": "Pop",
    "image": "/__l5e/assets-v1/497e5d77-c4c9-4234-83da-401e77a07340/sonora-selected-3.jpg"
  },
  {
    "name": "Shawn Mendes",
    "genre": "Pop",
    "image": "/__l5e/assets-v1/34c722a5-bd02-47ac-8359-2f933f9ec70f/sonora-selected-4.jpg"
  },
  {
    "name": "Fall Out Boy",
    "genre": "Rock",
    "image": "/__l5e/assets-v1/c39d4550-8048-4a00-b77f-48ce6d3478e1/sonora-selected-5.jpg"
  },
  {
    "name": "OneRepublic",
    "genre": "Pop",
    "image": "/__l5e/assets-v1/3bf9ef2f-2d40-486e-b520-c73ef561dd25/sonora-extra-11.jpg"
  },
  {
    "name": "Neon Trees",
    "genre": "Indie pop",
    "image": "/__l5e/assets-v1/0f8dbbbe-f276-454d-822c-2d52fa96a8f6/sonora-extra-12.jpg"
  },
  {
    "name": "WALK THE MOON",
    "genre": "Indie pop",
    "image": "/__l5e/assets-v1/dcd2df99-35b3-4589-9eca-5b6ed3812841/sonora-extra-13.jpg"
  },
  {
    "name": "Owl City & Carly Rae Jepsen",
    "genre": "Pop",
    "image": "/__l5e/assets-v1/73a0b8fd-770b-43e8-8ec2-0aa8a493d81b/sonora-extra-14.jpg"
  },
  {
    "name": "American Authors",
    "genre": "Indie pop",
    "image": "/__l5e/assets-v1/ebf0621f-f30a-4455-80fa-bda03e66fd6c/sonora-extra-15.jpg"
  }
];

const defaultPlaylists = [
  { id: "p1", name: "Para estudiar", songs: [1, 2, 3] },
  { id: "p2", name: "Energía total", songs: [4, 5, 1] }
];

/* ---------- 2. ESTADO Y ALMACENAMIENTO LOCAL ---------- */
function load(key, fallback) {
  try {
    const value = JSON.parse(localStorage.getItem(key));
    return value ?? fallback;
  } catch (error) {
    return fallback;
  }
}

function save(key, value) {
  localStorage.setItem(key, JSON.stringify(value));
}

let favorites = load("sonora_favorites", [1, 5]).filter(id => songs.some(song => song.id === id));          // ids de canciones favoritas
let playlists = load("sonora_playlists", defaultPlaylists).map(playlist => ({
  ...playlist, songs: playlist.songs.filter(id => songs.some(song => song.id === id))
})); // playlists del usuario
let user = load("sonora_user", null);                     // usuario con sesión iniciada

let queue = songs.map(s => s.id); // lista de reproducción actual
let currentId = null;             // canción cargada en el reproductor
let selectedGenre = "Todos";      // filtro de la sección Explorar
let openPlaylistId = null;        // playlist abierta en detalle

// Historial para los botones Atrás / Adelante
let viewHistory = ["inicio"];
let historyPos = 0;

/* ---------- 3. UTILIDADES ---------- */
const $ = (selector) => document.querySelector(selector);

const getSong = (id) => songs.find(s => s.id === Number(id));
const getPlaylist = (id) => playlists.find(p => p.id === id);
const isFavorite = (id) => favorites.includes(Number(id));
const isPlaying = () => !audio.paused && !audio.ended;

function formatTime(seconds) {
  if (!isFinite(seconds)) return "0:00";
  const min = Math.floor(seconds / 60);
  const sec = Math.floor(seconds % 60).toString().padStart(2, "0");
  return `${min}:${sec}`;
}

// Ventanas SweetAlert2 con el estilo de SONORA
const SonoraAlert = Swal.mixin({
  background: "#18181b",
  color: "#ffffff",
  buttonsStyling: false,
  reverseButtons: true,
  customClass: {
    popup: "swal-sonora",
    confirmButton: "btn btn-lime px-4",
    cancelButton: "btn btn-ghost px-4",
    denyButton: "btn btn-danger-s px-4"
  }
});

// Notificaciones pequeñas en la esquina
const Toast = Swal.mixin({
  toast: true,
  position: "top-end",
  showConfirmButton: false,
  timer: 2200,
  timerProgressBar: true,
  background: "#1f1f23",
  color: "#ffffff",
  iconColor: "#c6ff3d",
  customClass: { popup: "swal-sonora" }
});

/* ---------- 4. PLANTILLAS HTML ---------- */
function songCard(song) {
  const active = song.id === currentId;
  const playIcon = active && isPlaying() ? "bi-pause-fill" : "bi-play-fill";
  const fav = isFavorite(song.id);
  return `
    <div class="col-6 col-sm-4 col-xl-2">
      <article class="music-card ${active ? "playing" : ""}" data-action="play" data-id="${song.id}">
        <div class="cover-wrap">
          <img src="${song.cover}" alt="Portada de ${song.title}" loading="lazy">
          <button class="play-fab" data-action="play" data-id="${song.id}" aria-label="Reproducir ${song.title}">
            <i class="bi ${playIcon}"></i>
          </button>
        </div>
        <h3 class="card-title-s">${song.title}</h3>
        <p class="card-sub">${song.artist}</p>
        <div class="card-actions">
          <button class="icon-btn ${fav ? "active" : ""}" data-action="fav" data-id="${song.id}" aria-label="Favorita">
            <i class="bi ${fav ? "bi-heart-fill" : "bi-heart"}"></i>
          </button>
          <button class="icon-btn" data-action="add" data-id="${song.id}" aria-label="Agregar a playlist">
            <i class="bi bi-plus-circle"></i>
          </button>
        </div>
      </article>
    </div>`;
}

function songRow(song, index, queueIds, extraButton = "") {
  const active = song.id === currentId;
  const fav = isFavorite(song.id);
  const number = active && isPlaying() ? '<i class="bi bi-soundwave"></i>' : index + 1;
  return `
    <div class="song-row ${active ? "playing" : ""}" data-action="play" data-id="${song.id}" data-queue="${queueIds.join(",")}">
      <span class="row-num">${number}</span>
      <img src="${song.cover}" alt="Portada de ${song.title}" loading="lazy">
      <div class="row-info">
        <span class="row-title">${song.title}</span>
        <span class="row-artist">${song.artist}</span>
      </div>
      <span class="row-album d-none d-md-block">${song.album}</span>
      <div class="row-actions">
        <button class="icon-btn ${fav ? "active" : ""}" data-action="fav" data-id="${song.id}" aria-label="Favorita">
          <i class="bi ${fav ? "bi-heart-fill" : "bi-heart"}"></i>
        </button>
        <button class="icon-btn" data-action="add" data-id="${song.id}" aria-label="Agregar a playlist">
          <i class="bi bi-plus-circle"></i>
        </button>
        ${extraButton}
      </div>
    </div>`;
}

function playlistCover(playlist, cssClass) {
  const first = getSong(playlist.songs[0]);
  return first
    ? `<img class="${cssClass}" src="${first.cover}" alt="Portada de ${playlist.name}">`
    : `<div class="${cssClass} cover-empty mini-cover empty"><i class="bi bi-music-note-beamed"></i></div>`;
}

function playlistCard(playlist) {
  return `
    <div class="col-6 col-sm-4 col-xl-3">
      <article class="music-card" data-action="open-playlist" data-pl="${playlist.id}">
        <div class="cover-wrap">${playlistCover(playlist, "")}</div>
        <h3 class="card-title-s">${playlist.name}</h3>
        <p class="card-sub">${playlist.songs.length} canciones</p>
      </article>
    </div>`;
}

function emptyState(icon, text, buttonHtml = "") {
  return `<div class="empty-state"><i class="bi ${icon}"></i><p>${text}</p>${buttonHtml}</div>`;
}

/* ---------- 5. RENDERIZADO ---------- */
function renderHome() {
  const popular = [...songs].sort((a, b) => b.plays - a.plays).slice(0, 6);
  $("#popularGrid").innerHTML = popular.map(songCard).join("");

  $("#albumGrid").innerHTML = albums.map(album => `
    <div class="col-6 col-md-3">
      <article class="music-card" data-action="play-album" data-album="${album.id}">
        <div class="cover-wrap">
          <img src="${album.cover}" alt="Portada del álbum ${album.title}" loading="lazy">
          <button class="play-fab" data-action="play-album" data-album="${album.id}" aria-label="Reproducir álbum"><i class="bi bi-play-fill"></i></button>
        </div>
        <h3 class="card-title-s">${album.title}</h3>
        <p class="card-sub">${album.year} · ${album.artist}</p>
      </article>
    </div>`).join("");

  $("#artistGrid").innerHTML = artists.map(artist => `
    <div class="col-6 col-md-3">
      <article class="music-card artist-card" data-action="artist" data-name="${artist.name}">
        <div class="cover-wrap"><img src="${artist.image}" alt="Portada de un álbum de ${artist.name}" loading="lazy"></div>
        <h3 class="card-title-s">${artist.name}</h3>
        <p class="card-sub">Artista</p>
        <span class="badge-genre">${artist.genre}</span>
      </article>
    </div>`).join("");

  $("#homePlaylistGrid").innerHTML = playlists.length
    ? playlists.slice(0, 4).map(playlistCard).join("")
    : `<div class="col-12">${emptyState("bi-music-note-list", "Aún no tienes playlists.")}</div>`;

  $("#heroGreeting").textContent = user ? `Hola, ${user.name}` : "Bienvenido a SONORA";
}

function renderExplore() {
  const genres = ["Todos", ...new Set(songs.map(s => s.genre))];
  $("#genreChips").innerHTML = genres.map(g =>
    `<button class="chip ${g === selectedGenre ? "active" : ""}" data-action="genre" data-genre="${g}">${g}</button>`
  ).join("");

  const list = selectedGenre === "Todos" ? songs : songs.filter(s => s.genre === selectedGenre);
  $("#exploreGrid").innerHTML = list.map(songCard).join("");
}

function renderLibrary() {
  const ids = songs.map(s => s.id);
  $("#libraryCount").textContent = `${songs.length} canciones · ${albums.length} álbumes · ${artists.length} artistas`;
  $("#libraryList").innerHTML = songs.map((s, i) => songRow(s, i, ids)).join("");
}

function renderFavorites() {
  const favSongs = favorites.map(getSong).filter(Boolean);
  $("#favCount").textContent = favSongs.length;
  $("#favSubtitle").textContent = `${favSongs.length} canciones`;

  $("#favList").innerHTML = favSongs.length
    ? favSongs.map((s, i) => songRow(s, i, favorites)).join("")
    : emptyState("bi-heart", "Todavía no tienes favoritas. Toca el corazón en cualquier canción.",
        '<button class="btn btn-lime" data-action="view" data-view="explorar">Explorar música</button>');
}

function renderPlaylists() {
  // Lista corta de la barra lateral
  $("#sidebarPlaylists").innerHTML = playlists.map(p => `
    <li>
      <button data-action="open-playlist" data-pl="${p.id}">
        ${playlistCover(p, "mini-cover")}
        <div><span>${p.name}</span><small>Playlist · ${p.songs.length} canciones</small></div>
      </button>
    </li>`).join("");

  // Cuadrícula de todas las playlists
  const createCard = `
    <div class="col-6 col-sm-4 col-xl-3">
      <article class="music-card" data-action="new-playlist">
        <div class="cover-wrap"><div class="cover-empty"><i class="bi bi-plus-lg"></i></div></div>
        <h3 class="card-title-s">Crear playlist</h3>
        <p class="card-sub">Ponle el nombre que quieras</p>
      </article>
    </div>`;
  $("#playlistsGrid").innerHTML = playlists.map(playlistCard).join("") + createCard;

  // Detalle de una playlist abierta
  const playlist = getPlaylist(openPlaylistId);
  $("#playlistsOverview").classList.toggle("d-none", Boolean(playlist));
  $("#playlistDetail").classList.toggle("d-none", !playlist);
  if (!playlist) return;

  const plSongs = playlist.songs.map(getSong).filter(Boolean);
  const rows = plSongs.length
    ? plSongs.map((s, i) => songRow(s, i, playlist.songs,
        `<button class="icon-btn" data-action="remove-from-playlist" data-id="${s.id}" data-pl="${playlist.id}" aria-label="Quitar de la playlist"><i class="bi bi-dash-circle"></i></button>`
      )).join("")
    : emptyState("bi-plus-circle", "Esta playlist está vacía. Usa el botón + en cualquier canción para agregarla.");

  $("#playlistDetail").innerHTML = `
    <button class="link-btn mb-3" data-action="view" data-view="playlists"><i class="bi bi-arrow-left"></i> Todas las playlists</button>
    <div class="list-header">
      ${playlistCover(playlist, "list-cover")}
      <div>
        <p class="hero-kicker mb-1">Playlist</p>
        <h1 class="view-title mb-1">${playlist.name}</h1>
        <p class="text-muted-s">${plSongs.length} canciones</p>
        <div class="d-flex flex-wrap gap-2">
          <button class="btn btn-lime" data-action="play-playlist" data-pl="${playlist.id}" ${plSongs.length ? "" : "disabled"}>
            <i class="bi bi-play-fill"></i> Reproducir
          </button>
          <button class="btn btn-danger-s" data-action="delete-playlist" data-pl="${playlist.id}">
            <i class="bi bi-trash3"></i> Eliminar
          </button>
        </div>
      </div>
    </div>
    <div class="song-list">${rows}</div>`;
}

function renderSearch() {
  const query = $("#searchInput").value.trim().toLowerCase();
  if (!query) return;

  const results = songs.filter(s =>
    s.title.toLowerCase().includes(query) ||
    s.artist.toLowerCase().includes(query) ||
    s.album.toLowerCase().includes(query)
  );
  const ids = results.map(s => s.id);

  $("#searchTitle").textContent = `Resultados para "${$("#searchInput").value.trim()}"`;
  $("#searchResults").innerHTML = results.length
    ? results.map((s, i) => songRow(s, i, ids)).join("")
    : emptyState("bi-search", "No encontramos canciones, artistas ni álbumes con ese nombre.");
}

function renderPlayer() {
  const song = getSong(currentId);
  if (song) {
    $("#playerCover").src = song.cover;
    $("#playerCover").alt = `Portada de ${song.title}`;
    $("#playerTitle").textContent = song.title;
    $("#playerArtist").textContent = song.artist;
  }
  $("#btnPlay").innerHTML = `<i class="bi ${isPlaying() ? "bi-pause-fill" : "bi-play-fill"}"></i>`;
  $("#btnPlay").setAttribute("aria-label", isPlaying() ? "Pausar" : "Reproducir");

  const fav = song && isFavorite(song.id);
  $("#playerFav").classList.toggle("active", Boolean(fav));
  $("#playerFav").innerHTML = `<i class="bi ${fav ? "bi-heart-fill" : "bi-heart"}"></i>`;
}

function renderUser() {
  $("#btnLogin").classList.toggle("d-md-inline-block", !user);
  $("#btnProfile").classList.toggle("logged", Boolean(user));
  $("#avatarIcon").classList.toggle("d-none", Boolean(user));
  $("#avatarInitial").classList.toggle("d-none", !user);
  $("#avatarInitial").textContent = user ? user.name.charAt(0).toUpperCase() : "";
}

// Vuelve a dibujar todo (los datos son pocos, así que es rápido y sencillo)
function renderAll() {
  renderHome();
  renderExplore();
  renderLibrary();
  renderFavorites();
  renderPlaylists();
  renderSearch();
  renderPlayer();
  renderUser();
}

/* ---------- 6. NAVEGACIÓN ENTRE SECCIONES ---------- */
function showView(name, addToHistory = true) {
  document.querySelectorAll(".view").forEach(v => v.classList.toggle("active", v.id === `view-${name}`));
  document.querySelectorAll(".nav-btn[data-view]").forEach(b => b.classList.toggle("active", b.dataset.view === name));

  if (addToHistory && viewHistory[historyPos] !== name) {
    viewHistory = viewHistory.slice(0, historyPos + 1);
    viewHistory.push(name);
    historyPos++;
  }
  if (name !== "busqueda") $("#searchInput").value = "";

  $("#btnBack").disabled = historyPos === 0;
  $("#btnForward").disabled = historyPos === viewHistory.length - 1;

  window.scrollTo({ top: 0, behavior: "smooth" });

  // En celulares cerramos el menú lateral al navegar
  const offcanvas = bootstrap.Offcanvas.getInstance($("#sidebar"));
  if (offcanvas) offcanvas.hide();
}

function goBack() {
  if (historyPos > 0) { historyPos--; showView(viewHistory[historyPos], false); }
}

function goForward() {
  if (historyPos < viewHistory.length - 1) { historyPos++; showView(viewHistory[historyPos], false); }
}

/* ---------- 7. REPRODUCTOR DE AUDIO ---------- */
const audio = $("#audio");

function loadSong(id, autoplay = true) {
  const song = getSong(id);
  if (!song) return;
  currentId = song.id;
  audio.src = song.src;
  $("#progressBar").value = 0;
  updateRangeFill($("#progressBar"));
  $("#timeCurrent").textContent = "0:00";
  $("#timeDuration").textContent = "0:00";
  if (autoplay) {
    audio.play().catch(() => {});
    Toast.fire({ icon: "success", title: `Reproduciendo: ${song.title}` });
  }
  renderAll();
}

function playSong(id, queueIds) {
  if (queueIds && queueIds.length) queue = queueIds;
  if (Number(id) === currentId) {
    togglePlay();
  } else {
    loadSong(id);
  }
}

function togglePlay() {
  if (!currentId) return loadSong(queue[0]);
  if (audio.paused) audio.play().catch(() => {});
  else audio.pause();
}

function nextSong() {
  const index = queue.indexOf(currentId);
  loadSong(queue[(index + 1) % queue.length]);
}

function prevSong() {
  // Si la canción ya avanzó, primero vuelve al inicio
  if (audio.currentTime > 3) { audio.currentTime = 0; return; }
  const index = queue.indexOf(currentId);
  loadSong(queue[(index - 1 + queue.length) % queue.length]);
}

// Pinta de verde la parte recorrida de una barra deslizante
function updateRangeFill(range) {
  const percent = ((range.value - range.min) / (range.max - range.min)) * 100;
  range.style.setProperty("--fill", `${percent}%`);
}

function updateVolumeIcon() {
  let icon = "bi-volume-up-fill";
  if (audio.muted || audio.volume === 0) icon = "bi-volume-mute-fill";
  else if (audio.volume < 0.5) icon = "bi-volume-down-fill";
  $("#btnMute").innerHTML = `<i class="bi ${icon}"></i>`;
}

/* ---------- 8. FAVORITOS Y PLAYLISTS ---------- */
function toggleFavorite(id) {
  id = Number(id);
  const song = getSong(id);
  if (isFavorite(id)) {
    favorites = favorites.filter(f => f !== id);
    Toast.fire({ icon: "info", title: `"${song.title}" se quitó de favoritas` });
  } else {
    favorites.push(id);
    Toast.fire({ icon: "success", title: `"${song.title}" se agregó a favoritas` });
  }
  save("sonora_favorites", favorites);
  renderAll();
}

async function createPlaylist() {
  const { value: name } = await SonoraAlert.fire({
    title: "Nueva playlist",
    input: "text",
    inputPlaceholder: "Ej. Viaje en carretera",
    inputAttributes: { maxlength: 30 },
    showCancelButton: true,
    confirmButtonText: "Crear",
    cancelButtonText: "Cancelar",
    inputValidator: (value) => {
      const clean = value.trim();
      if (!clean) return "Escribe un nombre para tu playlist";
      if (playlists.some(p => p.name.toLowerCase() === clean.toLowerCase())) return "Ya tienes una playlist con ese nombre";
    }
  });
  if (!name) return null;

  const playlist = { id: "p" + Date.now(), name: name.trim(), songs: [] };
  playlists.push(playlist);
  save("sonora_playlists", playlists);
  renderAll();
  SonoraAlert.fire({ icon: "success", title: "¡Playlist creada!", text: `"${playlist.name}" ya está en tu colección.`, timer: 1800, showConfirmButton: false });
  return playlist;
}

async function addToPlaylist(songId) {
  const song = getSong(songId);
  const options = {};
  playlists.forEach(p => { options[p.id] = p.name; });
  options.nueva = "+ Crear nueva playlist";

  const { value: choice } = await SonoraAlert.fire({
    title: "Agregar a playlist",
    text: `${song.title} · ${song.artist}`,
    input: "select",
    inputOptions: options,
    inputPlaceholder: "Elige una playlist",
    showCancelButton: true,
    confirmButtonText: "Agregar",
    cancelButtonText: "Cancelar",
    inputValidator: (value) => !value && "Selecciona una opción"
  });
  if (!choice) return;

  const playlist = choice === "nueva" ? await createPlaylist() : getPlaylist(choice);
  if (!playlist) return;

  if (playlist.songs.includes(song.id)) {
    Toast.fire({ icon: "info", title: `Ya está en "${playlist.name}"` });
    return;
  }
  playlist.songs.push(song.id);
  save("sonora_playlists", playlists);
  renderAll();
  Toast.fire({ icon: "success", title: `Agregada a "${playlist.name}"` });
}

function removeFromPlaylist(songId, playlistId) {
  const playlist = getPlaylist(playlistId);
  playlist.songs = playlist.songs.filter(id => id !== Number(songId));
  save("sonora_playlists", playlists);
  renderAll();
  Toast.fire({ icon: "info", title: "Canción quitada de la playlist" });
}

async function deletePlaylist(playlistId) {
  const playlist = getPlaylist(playlistId);
  const result = await SonoraAlert.fire({
    icon: "warning",
    iconColor: "#ff6b6b",
    title: "¿Eliminar playlist?",
    text: `"${playlist.name}" se borrará de tu colección.`,
    showCancelButton: true,
    confirmButtonText: "Sí, eliminar",
    cancelButtonText: "Cancelar"
  });
  if (!result.isConfirmed) return;

  playlists = playlists.filter(p => p.id !== playlistId);
  save("sonora_playlists", playlists);
  openPlaylistId = null;
  renderAll();
  Toast.fire({ icon: "success", title: "Playlist eliminada" });
}

function openPlaylist(playlistId) {
  openPlaylistId = playlistId;
  renderPlaylists();
  showView("playlists");
}

/* ---------- 9. BÚSQUEDA ---------- */
function handleSearch() {
  const query = $("#searchInput").value.trim();
  if (!query) {
    if (viewHistory[historyPos] === "busqueda") goBack();
    return;
  }
  renderSearch();
  showView("busqueda");
}

function searchArtist(name) {
  $("#searchInput").value = name;
  handleSearch();
}

/* ---------- 10. INICIO DE SESIÓN / PERFIL ---------- */
async function login() {
  const { value: data } = await SonoraAlert.fire({
    title: "Inicia sesión en SONORA",
    html: `
      <input id="loginName" class="swal2-input" placeholder="Tu nombre" maxlength="30">
      <input id="loginEmail" class="swal2-input" type="email" placeholder="Correo electrónico">`,
    focusConfirm: false,
    showCancelButton: true,
    confirmButtonText: "Entrar",
    cancelButtonText: "Cancelar",
    preConfirm: () => {
      const name = document.getElementById("loginName").value.trim();
      const email = document.getElementById("loginEmail").value.trim();
      if (!name) return Swal.showValidationMessage("Escribe tu nombre");
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return Swal.showValidationMessage("Escribe un correo válido");
      return { name, email };
    }
  });
  if (!data) return;

  user = data;
  save("sonora_user", user);
  renderAll();
  SonoraAlert.fire({ icon: "success", title: `¡Hola, ${user.name}!`, text: "Iniciaste sesión correctamente.", timer: 1800, showConfirmButton: false });
}

async function showProfile() {
  if (!user) {
    const result = await SonoraAlert.fire({
      icon: "info",
      iconColor: "#c6ff3d",
      title: "Perfil de usuario",
      text: "Inicia sesión para ver tu perfil.",
      showCancelButton: true,
      confirmButtonText: "Iniciar sesión",
      cancelButtonText: "Ahora no"
    });
    if (result.isConfirmed) login();
    return;
  }

  const result = await SonoraAlert.fire({
    title: user.name,
    html: `<p class="mb-1">${user.email}</p>
           <p class="text-muted-s mb-0">${favorites.length} favoritas · ${playlists.length} playlists</p>`,
    showDenyButton: true,
    confirmButtonText: "Cerrar",
    denyButtonText: "Cerrar sesión"
  });
  if (result.isDenied) logout();
}

async function logout() {
  const result = await SonoraAlert.fire({
    icon: "question",
    iconColor: "#c6ff3d",
    title: "¿Cerrar sesión?",
    showCancelButton: true,
    confirmButtonText: "Sí, salir",
    cancelButtonText: "Cancelar"
  });
  if (!result.isConfirmed) return;
  user = null;
  localStorage.removeItem("sonora_user");
  renderAll();
  Toast.fire({ icon: "success", title: "Sesión cerrada" });
}

/* ---------- 11. EVENTOS ---------- */
// Un solo "escuchador" para todos los botones con data-action
document.addEventListener("click", (event) => {
  const el = event.target.closest("[data-action]");
  if (!el) return;
  const { action, id, pl, view } = el.dataset;

  switch (action) {
    case "view":
      if (view === "playlists") { openPlaylistId = null; renderPlaylists(); }
      showView(view);
      break;
    case "play": {
      const queueEl = el.closest("[data-queue]");
      const queueIds = queueEl ? queueEl.dataset.queue.split(",").map(Number) : songs.map(s => s.id);
      playSong(id, queueIds);
      break;
    }
    case "play-all":
      queue = [...songs].sort((a, b) => b.plays - a.plays).map(s => s.id);
      loadSong(queue[0]);
      break;
    case "play-album": {
      const album = albums.find(a => a.id === el.dataset.album);
      queue = album.songs;
      loadSong(queue[0]);
      break;
    }
    case "play-playlist": {
      const playlist = getPlaylist(pl);
      if (!playlist.songs.length) return;
      queue = playlist.songs;
      loadSong(queue[0]);
      break;
    }
    case "artist":          searchArtist(el.dataset.name); break;
    case "genre":           selectedGenre = el.dataset.genre; renderExplore(); break;
    case "fav":             toggleFavorite(id); break;
    case "add":             addToPlaylist(id); break;
    case "new-playlist":    createPlaylist(); break;
    case "open-playlist":   openPlaylist(pl); break;
    case "delete-playlist": deletePlaylist(pl); break;
    case "remove-from-playlist": removeFromPlaylist(id, pl); break;
  }
});

// Controles del reproductor
$("#btnPlay").addEventListener("click", togglePlay);
$("#btnNext").addEventListener("click", nextSong);
$("#btnPrev").addEventListener("click", prevSong);
$("#playerFav").addEventListener("click", () => currentId && toggleFavorite(currentId));

$("#progressBar").addEventListener("input", (e) => {
  if (audio.duration) audio.currentTime = (e.target.value / 100) * audio.duration;
  updateRangeFill(e.target);
});

$("#volumeBar").addEventListener("input", (e) => {
  audio.volume = e.target.value / 100;
  audio.muted = false;
  updateRangeFill(e.target);
  updateVolumeIcon();
});

$("#btnMute").addEventListener("click", () => {
  audio.muted = !audio.muted;
  updateVolumeIcon();
});

// Eventos del elemento <audio>
audio.addEventListener("play", renderAll);
audio.addEventListener("pause", renderAll);
audio.addEventListener("ended", nextSong);
audio.addEventListener("loadedmetadata", () => {
  $("#timeDuration").textContent = formatTime(audio.duration);
});
audio.addEventListener("timeupdate", () => {
  if (!audio.duration) return;
  $("#progressBar").value = (audio.currentTime / audio.duration) * 100;
  updateRangeFill($("#progressBar"));
  $("#timeCurrent").textContent = formatTime(audio.currentTime);
});
audio.addEventListener("error", () => {
  if (!audio.src) return;
  Toast.fire({ icon: "error", iconColor: "#ff6b6b", title: "No se pudo cargar el audio. Revisa tu conexión a internet." });
});

// Barra superior
$("#btnBack").addEventListener("click", goBack);
$("#btnForward").addEventListener("click", goForward);
$("#searchInput").addEventListener("input", handleSearch);
$("#btnLogin").addEventListener("click", login);
$("#btnProfile").addEventListener("click", showProfile);

/* ---------- INICIO ---------- */
audio.volume = 0.8;
updateRangeFill($("#volumeBar"));
loadSong(songs[0].id, false); // deja la primera canción lista en el reproductor
renderAll();
