# SONORA · Tu música, tu mundo

Proyecto académico: sitio web de música tipo streaming hecho con
HTML5, Bootstrap 5, CSS3, JavaScript puro y SweetAlert2.

## Estructura

```
sonora/
├── index.html      → estructura de la página
├── css/style.css   → estilos personalizados
├── js/script.js    → toda la lógica (reproductor, favoritos, playlists, búsqueda…)
└── img/            → portadas de ejemplo
```

## Cómo ejecutarlo en Visual Studio Code

1. Descomprime la carpeta y ábrela en VS Code (Archivo → Abrir carpeta).
2. Instala la extensión **Live Server** (de Ritwick Dey).
3. Clic derecho sobre `index.html` → **Open with Live Server**.

También puedes abrir `index.html` con doble clic en el navegador.
Se necesita conexión a internet: Bootstrap, SweetAlert2, las tipografías
y los fragmentos musicales y las nuevas portadas se cargan desde internet.

## Audios

El catálogo incluye las cinco canciones seleccionadas y diez canciones similares de pop, indie pop y rock:
- Take a Walk — Passion Pit.
- Mystical Magical — Benson Boone.
- La Da Dee — Cody Simpson.
- There's Nothing Holdin' Me Back — Shawn Mendes.
- Immortals — Fall Out Boy.
- Carried Away — Passion Pit.
- Beautiful Things — Benson Boone.
- On My Mind — Cody Simpson.
- Stitches — Shawn Mendes.
- My Songs Know What You Did In The Dark (Light Em Up) — Fall Out Boy.
- Counting Stars — OneRepublic.
- Animal — Neon Trees.
- Shut Up and Dance — WALK THE MOON.
- Good Time — Owl City & Carly Rae Jepsen.
- Best Day of My Life — American Authors.

Cada canción muestra la portada de su álbum correspondiente.
El audio corresponde a fragmentos oficiales del catálogo de Apple/iTunes,
de aproximadamente 30 segundos, no a canciones completas. No se repite ni ralentiza
el audio para simular una duración mayor. Para reproducir un minuto se necesitan
archivos de al menos 60 segundos con permiso de uso.
Los derechos pertenecen a sus respectivos titulares.
La disponibilidad de estos fragmentos puede cambiar según el proveedor.

## Funciones

- Reproducir / pausar, anterior / siguiente, barra de progreso, volumen y tiempo.
- Clic en cualquier tarjeta para reproducir esa canción.
- Buscar por canción, artista o álbum.
- Agregar y quitar favoritas (corazón).
- Crear y eliminar playlists, agregar y quitar canciones.
- Navegar entre Inicio, Explorar, Biblioteca, Playlists y Favoritas.
- Inicio de sesión de ejemplo (solo se guarda en el navegador).
- Los favoritos y playlists se guardan en el navegador con localStorage.
